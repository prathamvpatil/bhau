const express = require('express');
const bodyParser = require('body-parser'); 
const app = express();
const port = 3000;

// Use body-parser middleware
app.use(bodyParser.urlencoded({ extended: true })); 

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', './views'); // Set the views directory

app.get('/form', (req, res) => {
  res.render('form1'); // Render the first form
});

app.get('/form2', (req, res) => {
  res.render('form2'); // Render the second form
});

app.post('/submit', (req, res) => {
  const { ProductId, ProductName, Description } = req.body;

  // Basic validation
  if (!ProductId || !ProductName || !Description) {
    return res.status(400).send('All fields are required.');
  }

  console.log('Received data:', req.body); 
  res.send('Data submitted successfully!');
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});