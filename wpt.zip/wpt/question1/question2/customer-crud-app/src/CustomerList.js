import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import customerService from './services/customerService';

function CustomerList() {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await customerService.getAllCustomers();
        setCustomers(response.data);
      } catch (error) {
        console.error("Error fetching customers:", error);
      }
    };
    fetchCustomers();
  }, []);

  return (
    <div>
      <h2>Customer List</h2>
      <table>
        <thead>
          <tr>
            <th>Customer Name</th>
            <th>City</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <tr key={customer._id}> 
              <td>{customer.customerName}</td>
              <td>{customer.city}</td>
              <td>{customer.phone}</td>
              <td>{customer.emailId}</td>
              <td>
                <Link to={`/edit/${customer._id}`}>Edit</Link> |{' '}
                <Link to={`/details/${customer._id}`}>Details</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Link to="/add">Add Customer</Link>
    </div>
  );
}

export default CustomerList;