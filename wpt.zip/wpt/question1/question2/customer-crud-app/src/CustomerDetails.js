import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import customerService from './services/customerService';

function CustomerDetails() {
  const { id } = useParams();
  const [customer, setCustomer] = useState(null);

  useEffect(() => {
    const fetchCustomer = async () => {
      try {
        const response = await customerService.getCustomerById(id);
        setCustomer(response.data);
      } catch (error) {
        console.error("Error fetching customer:", error);
      }
    };
    fetchCustomer();
  }, [id]);

  if (!customer) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2>Customer Details</h2>
      {/* ... display customer details */}
    </div>
  );
}

export default CustomerDetails;