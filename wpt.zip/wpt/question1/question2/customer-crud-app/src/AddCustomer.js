import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import customerService from './services/customerService';

function AddCustomer() {
  const [customer, setCustomer] = useState({
    customerName: '',
    city: '',
    phone: '',
    emailId: '',
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomer({ ...customer, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await customerService.createCustomer(customer);
      navigate('/');
    } catch (error) {
      console.error("Error adding customer:", error);
    }
  };

  return (
    <div>
      <h2>Add Customer</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="customerName">Customer Name:</label>
          <input
            type="text"
            id="customerName"
            name="customerName"
            value={customer.customerName}
            onChange={handleChange}
          />
        </div>
        {/* ... other input fields for city, phone, emailId */}
        <button type="submit">Add Customer</button>
      </form>
    </div>
  );
}

export default AddCustomer;