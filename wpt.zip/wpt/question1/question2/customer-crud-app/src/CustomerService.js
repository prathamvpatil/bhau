import axios from 'axios';

const API_URL = 'http://localhost:3001/customers';

const getAllCustomers = async () => {
  const response = await axios.get(API_URL);
  return response.data;
};

const getCustomerById = async (id) => {
  const response = await axios.get(`${API_URL}/${id}`);
  return response.data;
};

const createCustomer = async (customer) => {
  const response = await axios.post(API_URL, customer);
  return response.data;
};

const updateCustomer = async (id, customer) => {
  const response = await axios.put(`${API_URL}/${id}`, customer);
  return response.data;
};

const deleteCustomer = async (id) => {
  await axios.delete(`${API_URL}/${id}`);
};

export default {
  getAllCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
};