document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("productForm").addEventListener("submit", function(event) {
        event.preventDefault();  // Prevents page reload

        let productName = document.getElementById("productName").value.trim();
        let introDate = document.getElementById("introDate").value.trim();
        let productUrl = document.getElementById("productUrl").value.trim();

        if (!productName || !introDate || !productUrl) {
            alert("Please fill all fields!"); 
            return;
        }

        // Ensure URL starts with "http://" or "https://"
        if (!/^https?:\/\//.test(productUrl)) {
            productUrl = "https://" + productUrl;
        }

        addProduct(productName, introDate, productUrl);
        this.reset(); // Clears the form after adding
    });

    function addProduct(name, date, url) {
        let tableBody = document.querySelector("#productTable tbody");

        let newRow = document.createElement("tr");
        newRow.innerHTML = `
            <td>${name}</td>
            <td>${date}</td>
            <td><a href="${url}" target="_blank">${url}</a></td>
            <td><button class="delete-btn">X</button></td>
        `;

        tableBody.appendChild(newRow);

        // Attach event listener to delete button
        newRow.querySelector(".delete-btn").addEventListener("click", function() {
            newRow.remove();
        });
    }
});
